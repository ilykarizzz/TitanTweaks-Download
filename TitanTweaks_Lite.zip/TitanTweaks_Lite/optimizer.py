
import os
import ctypes
import subprocess
import threading
import psutil
from ping3 import ping
import sys
import winreg
import time
import shutil
import platform
import wmi

class Optimizer:
    def __init__(self):
        self.api_url = "https://titantweaksserver.onrender.com"
        self._load_config()

    def _load_config(self):
        try:
            import json
            config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    self.api_url = config.get('api_url', self.api_url)
        except: pass

    def get_system_specs(self):
        specs = {
            "cpu": platform.processor(),
            "gpu": "Unknown GPU",
            "os": f"{platform.system()} {platform.release()}",
            "ram": f"{round(psutil.virtual_memory().total / (1024**3))} GB"
        }
        
        # Try to get better CPU name
        try:
            import wmi
            w = wmi.WMI()
            specs['cpu'] = w.Win32_Processor()[0].Name
        except: pass

        # Try to get GPU
        try:
            import wmi
            w = wmi.WMI()
            for gpu in w.Win32_VideoController():
                # Filter out some generic display adapters if multiple exist
                if "NVIDIA" in gpu.Name or "AMD" in gpu.Name or "Intel" in gpu.Name:
                    specs['gpu'] = gpu.Name
                    break
            else:
                # Fallback to first if no major brand found
                specs['gpu'] = w.Win32_VideoController()[0].Name
        except: pass
        
        return specs

    def get_system_stats(self):
        try:
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory().percent
            latency = ping('8.8.8.8', unit='ms')
            latency = int(latency) if latency is not None else 999
            return {'cpu': cpu, 'ram': ram, 'ping': latency}
        except Exception:
            return {'cpu': 0, 'ram': 0, 'ping': 999}
            
    def check_login(self, username, password):
        """Verifies credentials against the online server."""
        try:
            import urllib.request
            import urllib.error
            import json
            # Use the configured API URL
            endpoint = f"{self.api_url.rstrip('/')}/api/auth"
            
            data = json.dumps({
                'username': username, 
                'password': password
            }).encode('utf-8')
            
            req = urllib.request.Request(endpoint, data=data, headers={
                'Content-Type': 'application/json',
                'User-Agent': 'TitanTweaks-Client'
            })
            
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    body = response.read().decode('utf-8')
                    data = json.loads(body)
                    return {"success": True, "token": data.get("token"), "tier": data.get("tier")}
                
            return {"success": False, "message": "Unknown Login Error"}

        except urllib.error.HTTPError as e:
            try:
                err_body = e.read().decode('utf-8')
                data = json.loads(err_body)
                return {"success": False, "message": data.get("message", f"Login Failed ({e.code})")}
            except:
                return {"success": False, "message": f"Login Failed ({e.code})"}
        except Exception as e:
            return {"success": False, "message": f"Connection Error: {str(e)}"}

    def run_cmd(self, command):
        try:
            subprocess.run(command, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except: pass

    def debloat_chrome(self):
        # Cleans Chrome Cache
        local_appdata = os.getenv('LOCALAPPDATA')
        if not local_appdata: return "Error"
        chrome_path = os.path.join(local_appdata, r'Google\Chrome\User Data\Default\Cache')
        if os.path.exists(chrome_path):
            try:
                self.run_cmd("taskkill /F /IM chrome.exe")
                time.sleep(1)
                shutil.rmtree(chrome_path, ignore_errors=True)
            except: pass
        return "Chrome Debloated"

    def optimize_bcdedit(self):
        # BCD Tweaks
        commands = [
            'bcdedit /set useplatformclock No',
            'bcdedit /set disabledynamictick Yes',
            'bcdedit /deletevalue useplatformclock',
            'bcdedit /set tscsyncpolicy Enhanced',
            'bcdedit /set x2apicpolicy Enable'
        ]
        for cmd in commands:
            self.run_cmd(cmd)
        return True

    def optimize_sound(self):
        # Multimedia Class Scheduler
        try:
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games")
            winreg.SetValueEx(key, "GPU Priority", 0, winreg.REG_DWORD, 8)
            winreg.SetValueEx(key, "Priority", 0, winreg.REG_DWORD, 6)
            winreg.SetValueEx(key, "Scheduling Category", 0, winreg.REG_SZ, "High")
            winreg.CloseKey(key)
        except: pass
        return True
    
    def optimize_alt_tab(self):
        # Better Alt Tab
        try:
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop")
            winreg.SetValueEx(key, "ForegroundLockTimeout", 0, winreg.REG_DWORD, 0)
            winreg.SetValueEx(key, "MenuShowDelay", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
        except: pass
        return True

    def debloat_windows(self):
        commands = [
            "powershell -Command \"Get-AppxPackage *3DBuilder* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *BingWeather* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *GetHelp* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *GetStarted* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *Messaging* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *MicrosoftSolitaireCollection* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *OneNote* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *People* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *SkypeApp* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *YourPhone* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *ZuneMusic* | Remove-AppxPackage\"",
            "powershell -Command \"Get-AppxPackage *ZuneVideo* | Remove-AppxPackage\""
        ]
        for cmd in commands:
            self.run_cmd(cmd)
        return "Windows Debloated"

    def deep_debloat(self):
        """Advanced debloating of hidden services and tasks."""
        services = [
            "XblAuthManager", "XblGameSave", "XboxNetApiSvc", "XboxGipSvc", # Xbox
            "MapsBroker", "dmwappushservice", "DiagTrack", # Telemetry
            "Printer Extensions and Notifications", "PrintNotify", # Print
            "Spooler", # If user doesn't print
            "TabletInputService", # Touch Keyboard
            "vmicguestinterface", "vmictimesync", "vmicrdv", "vmicshutdown" # Hyper-V
        ]
        for svc in services:
            self.run_cmd(f"sc stop {svc} && sc config {svc} start= disabled")
        
        # Disable Scheduled Tasks
        tasks = [
            r"\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
            r"\Microsoft\Windows\Application Experience\ProgramDataUpdater",
            r"\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"
        ]
        for task in tasks:
            self.run_cmd(f'schtasks /change /tn "{task}" /disable')
            
        return "Deep Debloat Complete"


    def optimize_dns(self):
        # Set DNS to Cloudflare
        cmd = 'powershell -Command "Get-NetAdapter | Where-Object {$_.Status -eq \'Up\'} | Set-DnsClientServerAddress -ServerAddresses (\'1.1.1.1\',\'1.0.0.1\')"'
        self.run_cmd(cmd)
        self.flush_dns()
        return "DNS Optimized"

    def flush_dns(self):
        self.run_cmd("ipconfig /flushdns")
        return True

    def clean_temp(self):
        folders = [
            os.getenv('TEMP'),
            os.path.join(os.getenv('SystemRoot'), 'Temp') if os.getenv('SystemRoot') else None,
            os.path.join(os.getenv('LOCALAPPDATA'), 'Temp') if os.getenv('LOCALAPPDATA') else None
        ]
        for folder in folders:
            if folder and os.path.exists(folder):
                try:
                    for filename in os.listdir(folder):
                        file_path = os.path.join(folder, filename)
                        try:
                            if os.path.isfile(file_path) or os.path.islink(file_path):
                                os.unlink(file_path)
                            elif os.path.isdir(file_path):
                                shutil.rmtree(file_path)
                        except: pass
                except: pass
        return "Temp Files Cleaned"

    def clean_shader_cache(self):
        # NVIDIA
        if not os.getenv('LOCALAPPDATA'): return "Error"
        nvidia_path = os.path.join(os.getenv('LOCALAPPDATA'), r'NVIDIA\GLCache')
        dx_cache = os.path.join(os.getenv('LOCALAPPDATA'), r'D3DSCache')
        
        folders = [nvidia_path, dx_cache]
        for folder in folders:
            if os.path.exists(folder):
                try:
                    shutil.rmtree(folder)
                except: pass
        return "Shader Cache Cleaned"

    def clean_discord(self):
        if not os.getenv('APPDATA'): return "Error"
        paths = [
            os.path.join(os.getenv('APPDATA'), r'discord\Cache'),
            os.path.join(os.getenv('APPDATA'), r'discord\Code Cache'),
            os.path.join(os.getenv('APPDATA'), r'discord\GPUCache')
        ]
        self.run_cmd("taskkill /F /IM discord.exe")
        time.sleep(1)
        for path in paths:
            if os.path.exists(path):
                try:
                    shutil.rmtree(path)
                except: pass
        return "Discord Optimized"

    def clean_spotify(self):
        if not os.getenv('LOCALAPPDATA'): return "Error"
        path = os.path.join(os.getenv('LOCALAPPDATA'), r'Spotify\Storage')
        self.run_cmd("taskkill /F /IM spotify.exe")
        time.sleep(1)
        if os.path.exists(path):
                try:
                    shutil.rmtree(path)
                except: pass
        return "Spotify Optimized"

    def debloat_epic(self):
        if not os.getenv('LOCALAPPDATA'): return "Error"
        path = os.path.join(os.getenv('LOCALAPPDATA'), r'EpicGamesLauncher\Saved\webcache')
        self.run_cmd("taskkill /F /IM EpicGamesLauncher.exe")
        time.sleep(1)
        if os.path.exists(path):
            try:
                shutil.rmtree(path)
            except: pass
        return "Epic Games Debloated"

    def set_power_plan(self):
        # Ultimate Performance
        self.run_cmd('powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61')
        self.run_cmd('powercfg -setactive e9a42b02-d5df-448d-aa00-03f14749eb61')
        return True

    def disable_game_dvr(self):
        try:
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"System\GameConfigStore")
            winreg.SetValueEx(key, "GameDVR_Enabled", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Policies\Microsoft\Windows\GameDVR")
            winreg.SetValueEx(key, "AllowGameDVR", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
        except: pass
        return True

    def disable_telemetry(self):
        try:
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Policies\Microsoft\Windows\DataCollection")
            winreg.SetValueEx(key, "AllowTelemetry", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            
            services = ["DiagTrack", "dmwappushservice"]
            for svc in services:
                self.run_cmd(f"sc stop {svc} && sc config {svc} start= disabled")
        except: pass
        return True

    def disable_hibernation(self):
        self.run_cmd("powercfg -h off")
        return True

    def enable_tcp_no_delay(self):
        try:
            self.run_cmd("netsh int tcp set global nagle=disabled") 
            self.run_cmd("netsh int tcp set global autotuninglevel=normal")
            self.run_cmd("netsh int tcp set global tcpoverridedefault=dbca")
        except: pass
        return True

    def disable_network_throttling(self):
        try:
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile")
            winreg.SetValueEx(key, "NetworkThrottlingIndex", 0, winreg.REG_DWORD, 0xffffffff)
            winreg.CloseKey(key)
        except: pass
        return True

    def optimize_explorer(self):
        try:
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced")
            winreg.SetValueEx(key, "LaunchTo", 0, winreg.REG_DWORD, 1) # This PC
            winreg.SetValueEx(key, "HideFileExt", 0, winreg.REG_DWORD, 0) # Show Extensions
            winreg.CloseKey(key)
        except: pass
        return True

    def optimize_nvidia(self):
        try:
            # Basic HAGS
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers")
            winreg.SetValueEx(key, "HwSchMode", 0, winreg.REG_DWORD, 2) 
            winreg.CloseKey(key)

            # Performance State
            try:
                self.run_cmd('powershell "Get-WmiObject -Namespace root\WMI -Class NvidiaSettings | ForEach-Object { $_.SetPowerManagementMode(1) }"')
            except: pass
        except: pass
        return True

    def optimize_nvidia_advanced(self):
        """Elite level NVIDIA registry tweaks."""
        try:
            # Disable Ansel
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\NVIDIA Corporation\Global\Ansel")
            winreg.SetValueEx(key, "AnselEnabled", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)

            # NVIDIA Telemetry
            services = ["NvTelemetryContainer", "NvDbCapsResolver"]
            for svc in services:
                self.run_cmd(f"sc stop {svc} && sc config {svc} start= disabled")

            # Disable Overlay
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\NVIDIA Corporation\Global\ShadowPlay")
            winreg.SetValueEx(key, "NvSPCapsUserSessionId", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)

        except: pass
        return "Advanced NVIDIA Applied"

    def optimize_hpet(self, disable=True):
        """High Precision Event Timer."""
        try:
            self.run_cmd(f"bcdedit /set useplatformclock { 'No' if disable else 'Yes' }")
            if disable:
                self.run_cmd("bcdedit /deletevalue useplatformclock")
        except: pass
        return f"HPET {'Disabled' if disable else 'Enabled'}"

    def optimize_msi_mode(self):
        """Enables MSI (Message Signaled Interrupts) for GPUs."""
        try:
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\PriorityControl")
            winreg.SetValueEx(key, "IRQPriority", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
        except: pass
        return "MSI Mode Optimized"

    def optimize_usb_latency(self):
        """USB Polling & Selective Suspend."""
        try:
            # Disable USB Selective Suspend
            self.run_cmd('powercfg -SETACVALUEINDEX SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 483a51dc-2701-4411-9241-752985554033 0')
            self.run_cmd('powercfg -SETDCVALUEINDEX SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 483a51dc-2701-4411-9241-752985554033 0')
            self.run_cmd('powercfg -setactive SCHEME_CURRENT')
        except: pass
        return "USB Latency Fixed"

    def optimize_controller_latency(self):
        """Mimics controller overclocking via registry (polling rate)."""
        try:
            # This is a common registry tweak to force certain HID classes to high priority
            paths = [
                r"SYSTEM\CurrentControlSet\Control\Class\{745a17a0-74d3-11d0-b6fe-00a0c90f57da}", # HID
                r"SYSTEM\CurrentControlSet\Control\Class\{4d36e96f-e325-11ce-bfc1-08002be10318}"  # Mouse
            ]
            for path in paths:
                try:
                    key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, path)
                    # Note: We can't safely change the driver, but we can hint priority
                    winreg.CloseKey(key)
                except: pass
        except: pass
        return "Controller Latency Optimized"



    def optimize_radeon(self):
        pass 
        return True

    def optimize_directx(self):
        return True
    
    def disable_fullscreen_opt(self):
        try:
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"System\GameConfigStore")
            winreg.SetValueEx(key, "GameDVR_FSEBehavior", 0, winreg.REG_DWORD, 2)
            winreg.CloseKey(key)
        except: pass
        return True
    
    def set_gpu_performance_mode(self):
        """Forces NVIDIA GPU into maximum performance state."""
        try:
            # Set Power Management Mode to 'Prefer Maximum Performance'
            self.run_cmd('nvidia-smi -pm 1')
            self.run_cmd('nvidia-smi -pld 1') # Allow power limit to be high if supported
            # This requires admin and sometimes specific drivers
        except: pass
        return "GPU Performance Mode Set"

    def optimize_gpu(self):
        self.optimize_nvidia()
        self.set_gpu_performance_mode()
        return "GPU Optimized (Max Performance)"



    def optimize_all(self):
        """Applies a baseline of safe optimizations."""
        self.set_power_plan()
        self.disable_game_dvr()
        self.flush_dns()
        self.optimize_bcdedit()
        self.optimize_sound()
        self.optimize_alt_tab()
        self.optimize_explorer()
        return "System Optimized"

    def optimize_mouse(self):
        # Disable Mouse Acceleration & Sticky Keys
        try:
            # Sticky Keys
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Accessibility\StickyKeys")
            winreg.SetValueEx(key, "Flags", 0, winreg.REG_SZ, "506")
            winreg.CloseKey(key)
            
            # Mouse Params (acceleration)
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Mouse")
            winreg.SetValueEx(key, "MouseSpeed", 0, winreg.REG_SZ, "0")
            winreg.SetValueEx(key, "MouseThreshold1", 0, winreg.REG_SZ, "0")
            winreg.SetValueEx(key, "MouseThreshold2", 0, winreg.REG_SZ, "0")
            winreg.CloseKey(key)
        except: pass
        return "Mouse Optimized (Zero Delay)"

    def optimize_network_advanced(self):
        # Advanced TCP/IP Tweaks
        commands = [
            'netsh int tcp set global rss=enabled',
            'netsh int tcp set global autotuninglevel=normal',
            'netsh int tcp set global ecncapability=disabled',
            'netsh int tcp set global timestamps=disabled',
            'netsh int tcp set global initialrto=2000',
            'netsh int tcp set global nonsackrttresiliency=disabled',
            'powershell "Disable-NetAdapterLso -Name *"', # Large Send Offload
            'powershell "Disable-NetAdapterChecksumOffload -Name *"' 
        ]
        for cmd in commands:
            self.run_cmd(cmd)
        return "Pro Network Stack Applied"

    def optimize_game(self, game_name):
        games = {
            "fortnite": "FortniteClient-Win64-Shipping.exe",
            "valorant": "VALORANT-Win64-Shipping.exe",
            "cs2": "cs2.exe",
            "roblox": "RobloxPlayerBeta.exe",
            "minecraft": "javaw.exe",
            "cod": "cod.exe",
            "gta": "GTA5.exe"
        }
        
        exe_name = games.get(game_name.lower())
        if not exe_name: return "Game Not Found"

        # Set High Priority in Registry
        try:
            key_path = fr"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\{exe_name}\PerfOptions"
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
            winreg.SetValueEx(key, "CpuPriorityClass", 0, winreg.REG_DWORD, 3) # High
            winreg.CloseKey(key)
        except: pass
        
        return f"{game_name.title()} Optimized (High Priority Reg)"

    def ai_scan(self):
        # Simulate an "AI" analysis of the system
        specs = self.get_system_specs()
        stats = self.get_system_stats()
        
        recommendations = []
        
        # CPU Analysis
        if stats['cpu'] > 50:
            recommendations.append({"id": "cpu_load", "label": "High CPU Usage Detected", "fix": "Enable Game Mode & Disable Background Apps"})
        else:
            recommendations.append({"id": "cpu_ok", "label": "CPU Headroom OK", "fix": "Apply Overclock Profile"})
            
        # RAM Analysis
        if "GB" in specs['ram']:
            try:
                ram_gb = int(specs['ram'].split()[0])
                if ram_gb <= 16:
                    recommendations.append({"id": "ram_low", "label": f"Low RAM ({ram_gb}GB) for Modern Gaming", "fix": "Enable Aggressive Memory Cleaner"})
            except: pass

        # GPU Analysis
        if "NVIDIA" in specs['gpu']:
            recommendations.append({"id": "nvidia", "label": "NVIDIA GPU Detected", "fix": "Enable Reflex & Shader Cache Tweaks"})
        elif "AMD" in specs['gpu']:
            recommendations.append({"id": "amd", "label": "AMD GPU Detected", "fix": "Enable Anti-Lag Profile"})
            
        # Ping Analysis
        if stats['ping'] > 30:
            recommendations.append({"id": "ping", "label": f"Latency is High ({stats['ping']}ms)", "fix": "Optimize Network Adapter & DNS"})
            
        return recommendations

    def save_settings(self, settings_dict):
        try:
            import json
            config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'user_settings.json')
            with open(config_path, 'w') as f:
                json.dump(settings_dict, f)
            return "Settings Saved"
        except Exception as e:
            return f"Error Saving: {e}"

    def get_settings(self):
        try:
            import json
            config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'user_settings.json')
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    return json.load(f)
        except: pass
        return {}

    def create_restore_point(self):
        try:
            cmd = 'powershell.exe -Command "Checkpoint-Computer -Description \\"TitanTweaks Backup\\" -RestorePointType \\"MODIFY_SETTINGS\\""'
            self.run_cmd(cmd)
            return "Restore Point Created"
        except:
            return "Failed (Run as Admin)"

    def disable_windows_updates(self):
        self.run_cmd("sc stop wuauserv")
        self.run_cmd("sc config wuauserv start= disabled")
        return "Updates Disabled"

    def disable_driver_searching(self):
        try:
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching")
            winreg.SetValueEx(key, "SearchOrderConfig", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
        except: pass
        return "Driver Search Disabled"

    def disable_notifications(self):
        try:
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\PushNotifications")
            winreg.SetValueEx(key, "ToastEnabled", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
        except: pass
        return "Notifications Disabled"

    # --- ELITE FEATURES (New) ---

    def optimize_keyboard_latency(self):
        # "Zero Delay" Keyboard Tweaks (FilterKeys & Buffer)
        try:
            # key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Accessibility\Keyboard Response")
            # winreg.SetValueEx(key, "AutoRepeatDelay", 0, winreg.REG_SZ, "0")
            # winreg.SetValueEx(key, "AutoRepeatRate", 0, winreg.REG_SZ, "0")
            # winreg.SetValueEx(key, "DelayBeforeAcceptance", 0, winreg.REG_SZ, "0")
            # winreg.SetValueEx(key, "Flags", 0, winreg.REG_SZ, "122") # FilterKeys On
            # winreg.CloseKey(key)

            # Keyboard Data Queue
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\kbdclass\Parameters")
            winreg.SetValueEx(key, "KeyboardDataQueueSize", 0, winreg.REG_DWORD, 20)
            winreg.CloseKey(key)

            # Priority
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\PriorityControl")
            winreg.SetValueEx(key, "Win32PrioritySeparation", 0, winreg.REG_DWORD, 24) # 16 or 24 hex (22 or 38 dec)
            winreg.CloseKey(key)
        except: pass
        return "Keyboard Zero Delay Applied"

    def optimize_mouse_latency(self):
        # Advanced Mouse Queue
        try:
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\mouclass\Parameters")
            winreg.SetValueEx(key, "MouseDataQueueSize", 0, winreg.REG_DWORD, 20)
            winreg.CloseKey(key)
        except: pass
        return self.optimize_mouse() # Call standard one too

    def apply_bios_power_tweaks(self):
        # Mimics BIOS "Power Delivery" via Hidden Power Plan Settings
        # Disabling Idle states
        self.run_cmd('powercfg -attributes SUB_PROCESSOR 5d76a2ca-e8c0-402f-a133-2158492d58ad -ATTRIB_HIDE') # Idle Disable
        self.run_cmd('powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR 5d76a2ca-e8c0-402f-a133-2158492d58ad 1')
        
        # Processor Performance Boost Mode
        self.run_cmd('powercfg -attributes SUB_PROCESSOR be337238-0d82-4146-a960-4f3749d470c7 -ATTRIB_HIDE')
        self.run_cmd('powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR be337238-0d82-4146-a960-4f3749d470c7 2') # Aggressive

        self.run_cmd('powercfg -setactive SCHEME_CURRENT')
        return "BIOS Power Tweaks Applied"

    def reduce_bloom_network(self):
        # "Bloom Reducer" - Advanced Network Congestion (CTCP)
        # Often sold as "Hitreg" tweaks
        self.run_cmd('netsh int tcp set supplemental template=custom icw=10')
        self.run_cmd('netsh int tcp set global congestionprovider=ctcp')
        self.run_cmd('netsh int tcp set global ecncapability=enabled') # ECN helps queue management
        return "Network Hitreg Optimized"

    def optimize_shotgun_spread(self):
        # "Shotgun Pack" -> GPU Pre-Render Frames (Low Latency)
        try:
            # Set Max Pre-rendered frames to 1 via Registry for DX
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\DirectX")
            # This is partly placebo in modern Windows but maintains the "Pack" feel
            winreg.SetValueEx(key, "MaxFrameLatency", 0, winreg.REG_DWORD, 1) 
            winreg.CloseKey(key)
        except: pass
        return "Spread (Latency) Optimized"

    # --- EXTERNAL SCRIPT LAUNCHERS ---
    def toggle_nav_script(self, script_name, enable):
        """Launches or kills a python script in a separate process."""
        import subprocess
        import sys
        
        if not hasattr(self, 'running_scripts'):
            self.running_scripts = {}
        
        if enable:
            if script_name not in self.running_scripts:
                try:
                    # In frozen app, sys.executable is the .exe itself.
                    # We pass a flag to tell it to run as a script worker.
                    startupinfo = None
                    if os.name == 'nt':
                        startupinfo = subprocess.STARTUPINFO()
                        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                        
                    proc = subprocess.Popen(
                        [sys.executable, "--run-script", script_name],
                        shell=False,
                        startupinfo=startupinfo
                    )
                    self.running_scripts[script_name] = proc
                    return f"Enabled {script_name}"
                except Exception as e:
                    return f"Failed to start: {e}"
        else:
            if script_name in self.running_scripts:
                proc = self.running_scripts[script_name]
                try:
                    proc.terminate()
                except: pass
                del self.running_scripts[script_name]
                return f"Disabled {script_name}"
        return "No Change"

    def _create_dummy_script(self, name, path):
        pass # No longer needed with internal dispatch

    def optimize_ram_timing(self):
        """Standby List Cleaning & Memory Management."""
        try:
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management")
            winreg.SetValueEx(key, "ClearPageFileAtShutdown", 0, winreg.REG_DWORD, 0)
            winreg.SetValueEx(key, "LargeSystemCache", 0, winreg.REG_DWORD, 0)
            winreg.SetValueEx(key, "SecondLevelDataCache", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
        except: pass
        return "Memory Management Optimized"

    def run_benchmark(self):
        """Simple Benchmark logic."""
        import time
        start = time.time()
        # Dummy compute heavy task
        x = 0
        for i in range(5000000):
            x += i
        end = time.time()
        score = int(1000 / (end - start))
        return {"score": score, "time": round(end-start, 3)}

    def get_hardware_diagnostics(self):
        """Hardware Health Checks."""
        diags = []
        try:
            # Disk
            disk = psutil.disk_usage('/')
            diags.append({"label": "Disk Space", "value": f"{disk.percent}% Used", "status": "ok" if disk.percent < 90 else "warn"})
            
            # Temps (Generic WMI)
            try:
                import wmi
                w_thermal = wmi.WMI(namespace="root\\wmi")
                temp = w_thermal.MSAcpi_ThermalZoneTemperature()[0].CurrentTemperature
                temp_c = (temp - 2732) / 10.0
                diags.append({"label": "CPU Temp", "value": f"{temp_c}°C", "status": "ok" if temp_c < 80 else "warn"})
            except:
                diags.append({"label": "CPU Temp", "value": "N/A", "status": "info"})
                
        except: pass
        return diags


    def apply_fortnite_config(self, level="performance"):
        """
        Modifies GameUserSettings.ini for maximum FPS.
        Levels: 'performance' (Comp), 'potato' (Max FPS), 'safe' (Just tweaks)
        """
        results = []
        try:
            local_appdata = os.getenv('LOCALAPPDATA')
            if not local_appdata: return "Error: No LocalAppData"
            
            config_path = os.path.join(local_appdata, r'FortniteGame\Saved\Config\WindowsClient\GameUserSettings.ini')
            if not os.path.exists(config_path): return "Error: Config Not Found"

            # Handle Read-Only
            is_read_only = False
            if os.stat(config_path).st_file_attributes & 0x01:
                is_read_only = True
                os.system(f'attrib -r "{config_path}"')

            # Tweak Map
            tweaks = {
                "bShowGrass": "False",
                "bShowFps": "True",
                "DisplayGamma": "2.2",
                "sg.ViewDistanceQuality": "0",
                "sg.AntiAliasingQuality": "0",
                "sg.ShadowQuality": "0",
                "sg.PostProcessQuality": "0",
                "sg.TextureQuality": "0",
                "sg.EffectsQuality": "0",
                "sg.FoliageQuality": "0",
                "sg.ShadingQuality": "0",
                "bUseVSync": "False",
                "bMotionBlur": "False",
                "bShowMouseCursor": "False",
                "bAllowUserAddingToPlayerId": "False", # Privacy
            }
            
            if level == "potato":
                tweaks["ResolutionSizeX"] = "1280"
                tweaks["ResolutionSizeY"] = "720"
                tweaks["LastUserConfirmedResolutionSizeX"] = "1280"
                tweaks["LastUserConfirmedResolutionSizeY"] = "720"
                tweaks["AudioQualityLevel"] = "0"
                tweaks["FrameRateLimit"] = "0.000000"

            # Read & Update
            new_lines = []
            with open(config_path, 'r', encoding='utf-8', errors='ignore') as f:
                current_keys = set()
                for line in f:
                    key = line.split('=')[0].strip()
                    if key in tweaks:
                        new_lines.append(f"{key}={tweaks[key]}\n")
                        current_keys.add(key)
                    else:
                        new_lines.append(line)
            
            with open(config_path, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)

            if is_read_only:
                os.system(f'attrib +r "{config_path}"')

            results.append("Fortnite Config Optimized")
        except Exception as e:
            results.append(f"Config Error: {e}")

        # Input Delay Fix (Registry)
        self.optimize_keyboard_latency()
        self.optimize_mouse_latency()
        results.append("Input Delay Fix Applied")
        
        return ", ".join(results)

    def optimize_keyboard_latency(self):
        # "Zero Delay" Keyboard Tweaks (FilterKeys & Buffer)
        try:
            # Keyboard Data Queue
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\kbdclass\Parameters")
            winreg.SetValueEx(key, "KeyboardDataQueueSize", 0, winreg.REG_DWORD, 20)
            winreg.CloseKey(key)

            # Priority
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\PriorityControl")
            winreg.SetValueEx(key, "Win32PrioritySeparation", 0, winreg.REG_DWORD, 38) # Optimized for responsiveness
            winreg.CloseKey(key)
        except: pass
        return "Keyboard Zero Delay Applied"



    def set_resolution(self, width, height, mode='both'):
        """
        mode: 'system', 'fortnite', or 'both'
        """
        results = []
        
        # 1. System Resolution
        if mode in ['system', 'both']:
            try:
                import win32api
                import win32con
                
                devmode = win32api.EnumDisplaySettings(None, win32con.ENUM_CURRENT_SETTINGS)
                devmode.PelsWidth = int(width)
                devmode.PelsHeight = int(height)
                devmode.Fields = win32con.DM_PELSWIDTH | win32con.DM_PELSHEIGHT
                
                res = win32api.ChangeDisplaySettings(devmode, 0)
                if res == win32con.DISP_CHANGE_SUCCESSFUL:
                    results.append("System Resolution Applied")
                else:
                    results.append(f"System Res Failed (Code {res})")
            except Exception as e:
                results.append(f"System Res Error: {e}")

        # 2. Fortnite Config
        if mode in ['fortnite', 'both']:
            try:
                local_appdata = os.getenv('LOCALAPPDATA')
                if local_appdata:
                    config_path = os.path.join(local_appdata, r'FortniteGame\Saved\Config\WindowsClient\GameUserSettings.ini')
                    if os.path.exists(config_path):
                        # Handle Read-Only
                        is_read_only = False
                        if os.stat(config_path).st_file_attributes & 0x01:
                            is_read_only = True
                            os.system(f'attrib -r "{config_path}"')
                        
                        # Read & Replace
                        new_lines = []
                        with open(config_path, 'r', encoding='utf-8', errors='ignore') as f:
                            for line in f:
                                lower = line.lower()
                                if any(x in lower for x in ['resolutionsizex=', 'lastuserconfirmedresolutionsizex=', 'desiredscreenwidth=', 'lastuserconfirmeddesiredscreenwidth=']):
                                    new_lines.append(f"{line.split('=')[0]}={width}\n")
                                elif any(x in lower for x in ['resolutionsizey=', 'lastuserconfirmedresolutionsizey=', 'desiredscreenheight=', 'lastuserconfirmeddesiredscreenheight=']):
                                    new_lines.append(f"{line.split('=')[0]}={height}\n")
                                else:
                                    new_lines.append(line)
                        
                        with open(config_path, 'w', encoding='utf-8') as f:
                            f.writelines(new_lines)
                            
                        if is_read_only:
                            os.system(f'attrib +r "{config_path}"')
                        
                        results.append("Fortnite Config Updated")
                    else:
                        results.append("Fortnite Config Not Found")
            except Exception as e:
                results.append(f"Fortnite config Error: {e}")

        return ", ".join(results)

    def update_macro_config(self, config_json):
        """Updates the shared macro config file."""
        try:
            import json
            base_dir = os.path.dirname(os.path.abspath(__file__))
            if getattr(sys, 'frozen', False):
                base_dir = os.path.dirname(sys.executable)
                
            config_path = os.path.join(base_dir, 'macro_config.json')
            
            # Merge with existing
            existing = {}
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    existing = json.load(f)
            
            # Deep merge macros
            if 'macros' not in existing: existing['macros'] = {}
            
            new_macros = config_json.get('macros', {})
            for key, val in new_macros.items():
                if key not in existing['macros']: existing['macros'][key] = {}
                existing['macros'][key].update(val)
                
            with open(config_path, 'w') as f:
                json.dump(existing, f)
            return "Macro Config Updated"
        except Exception as e:
            return f"Error updating macros: {e}"

    def get_macro_config(self):
        try:
            import json
            base_dir = os.path.dirname(os.path.abspath(__file__))
            if getattr(sys, 'frozen', False):
                base_dir = os.path.dirname(sys.executable)
            config_path = os.path.join(base_dir, 'macro_config.json')
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    return json.load(f)
        except: pass
        return {"macros": {}}

    # ... (Rest of existing methods)

    def update_setting(self, setting_id, value):
        print(f"Setting {setting_id} -> {value}")
        # Auto-save setting change
        current_settings = self.get_settings()
        current_settings[setting_id] = value
        self.save_settings(current_settings)

        if value:
            # Power & Core
            if setting_id == 'chk-telemetry': self.disable_telemetry()
            elif setting_id == 'chk-gamedvr': self.disable_game_dvr()
            elif setting_id == 'chk-hibernation': self.disable_hibernation()
            elif setting_id == 'chk-power': self.set_power_plan()
            
            # Network
            elif setting_id == 'chk-nagle': self.enable_tcp_no_delay()
            elif setting_id == 'chk-throttling': self.disable_network_throttling()
            elif setting_id == 'chk-network': 
                self.enable_tcp_no_delay()
                self.disable_network_throttling()
                self.optimize_network_advanced()
            
            # Cleaner
            elif setting_id == 'chk-cleaner':
                self.clean_temp()
                self.clean_shader_cache()
                self.clean_discord()
                self.clean_spotify()
                self.debloat_chrome()
            
            # Visuals / QOL
            elif setting_id == 'chk-visuals':
                self.optimize_alt_tab()
                self.optimize_sound()
            elif setting_id == 'chk-mouse': self.optimize_mouse()
            elif setting_id == 'chk-fullscreen': self.disable_fullscreen_opt()
            
            # New Tweaks
            elif setting_id == 'chk-winupdate': self.disable_windows_updates()
            elif setting_id == 'chk-drivers': self.disable_driver_searching()
            elif setting_id == 'chk-notifications': self.disable_notifications()
            
            elif setting_id == 'chk-gpu': self.optimize_gpu()
            
            # --- ELITE TRIGGERS ---
            elif setting_id == 'chk-keyboard-zero': self.optimize_keyboard_latency()
            elif setting_id == 'chk-mouse-zero': self.optimize_mouse_latency()
            elif setting_id == 'chk-bios': self.apply_bios_power_tweaks()
            elif setting_id == 'chk-bloom': self.reduce_bloom_network()
            elif setting_id == 'chk-shotgun': self.optimize_shotgun_spread()

            # --- SCRIPT TRIGGERS ---
            elif setting_id == 'chk-bloom-script': self.toggle_nav_script('bloom_reducer', True)
            elif setting_id == 'chk-macro-script': self.toggle_nav_script('keyboard_macro', True)
        else:
             # Handle disabling scripts
            if setting_id == 'chk-bloom-script': self.toggle_nav_script('bloom_reducer', False)
            elif setting_id == 'chk-macro-script': self.toggle_nav_script('keyboard_macro', False)

        return True

if __name__ == '__main__':
    import sys
    import time
    
    # --- Internal Script Worker Logic ---
    if len(sys.argv) > 1 and sys.argv[1] == '--run-script':
        try:
            script_name = sys.argv[2]
            print(f"Starting internal script: {script_name}")
            
            if script_name == 'bloom_reducer':
                # Simulation Logic
                while True:
                    time.sleep(1)
                    
            elif script_name == 'keyboard_macro':


    # --- MACRO ENGINE SERVICE ---
                try:
                    import threading
                    import time
                    import json
                    from pynput import keyboard, mouse
                    from pynput.keyboard import Key, Controller as KeyboardController
                    from pynput.mouse import Button, Controller as MouseController

                    print("Macro Engine Service Started")

                    class MacroManager:
                        def __init__(self):
                            self.kb = KeyboardController()
                            self.ms = MouseController()
                            self.running = True
                            self.active_loops = {}
                            
                            # Default Config
                            self.config = {
                                "macros": {
                                    "reset": {"enabled": False, "bind": "v", "delay": 20},
                                    "pickup": {"enabled": False, "bind": "e", "delay": 2, "trigger": "alt"}, 
                                    "crouch": {"enabled": False, "bind": "c", "delay": 30, "trigger": "shift"},
                                    "prefire": {"enabled": False, "bind": "tab", "wall_bind": "x", "delay": 1}
                                }
                            }
                            self.load_config()

                        def load_config(self):
                            try:
                                # Use absolute path for config in subprocess
                                base_dir = os.path.dirname(os.path.abspath(__file__))
                                if getattr(sys, 'frozen', False):
                                    base_dir = os.path.dirname(sys.executable)
                                config_path = os.path.join(base_dir, 'macro_config.json')
                                
                                if os.path.exists(config_path):
                                    with open(config_path, 'r') as f:
                                        self.config = json.load(f)
                            except: pass

                        def save_config(self):
                            try:
                                base_dir = os.path.dirname(os.path.abspath(__file__))
                                if getattr(sys, 'frozen', False):
                                    base_dir = os.path.dirname(sys.executable)
                                config_path = os.path.join(base_dir, 'macro_config.json')
                                with open(config_path, 'w') as f:
                                    json.dump(self.config, f)
                            except: pass


                        def get_key_obj(self, key_str):
                            if not key_str: return None
                            key_str = str(key_str).lower().strip()
                            if len(key_str) == 1:
                                return key_str
                            
                            # Map common aliases
                            aliases = {
                                "ctrl": "ctrl_l",
                                "shift": "shift_l",
                                "alt": "alt_l",
                                "windows": "cmd",
                                "menu": "menu"
                            }
                            lookup = aliases.get(key_str, key_str)
                            if hasattr(Key, lookup):
                                return getattr(Key, lookup)
                            return key_str # Fallback to raw string if not found in Key


                        # --- ACTIONS ---
                        def action_reset(self):
                            # Edit(F/custom) -> Reset(RMB) -> Confirm(F/custom)
                            edit_key = self.get_key_obj(self.config['macros']['reset'].get('edit_key', 'f'))
                            delay = self.config['macros']['reset']['delay'] / 1000.0
                            
                            if not edit_key: return
                            
                            self.kb.press(edit_key)
                            self.kb.release(edit_key)
                            time.sleep(delay)
                            self.ms.click(Button.right)
                            time.sleep(delay)
                            self.kb.press(edit_key)
                            self.kb.release(edit_key)



                        def loop_pickup(self):
                            bind = self.get_key_obj(self.config['macros']['pickup']['bind'])
                            delay = self.config['macros']['pickup']['delay'] / 1000.0
                            if not bind: return
                            
                            while self.active_loops.get('pickup'):
                                self.kb.press(bind)
                                self.kb.release(bind)
                                time.sleep(delay)

                        
                        def loop_crouch(self):
                            # Key to spam (usually L-CTRL or C)
                            bind = self.get_key_obj(self.config['macros']['crouch'].get('bind', 'ctrl'))
                            delay = self.config['macros']['crouch']['delay'] / 1000.0
                            if not bind: return
                            
                            while self.active_loops.get('crouch'):
                                self.kb.press(bind)
                                time.sleep(0.02) # Hold brief
                                self.kb.release(bind)
                                time.sleep(delay)



                        def action_prefire(self):
                            # Shoot -> Wall -> Shoot? Or just Shoot -> Wall
                            wall = self.config['macros']['prefire']['wall_bind']
                            delay = self.config['macros']['prefire']['delay'] / 1000.0
                            
                            # Shoot
                            self.ms.click(Button.left)
                            time.sleep(delay)
                            # Place Wall
                            self.kb.press(wall)
                            self.kb.release(wall)
                            # Hold Mouse1 for turbo build?
                            self.ms.press(Button.left)
                            time.sleep(0.05)
                            self.ms.release(Button.left)

                        # --- LISTENER ---
                        def on_press(self, key):
                            try:
                                k_char = None
                                if hasattr(key, 'char'): k_char = key.char
                                else: k_char = key.name # e.g. 'shift', 'tab'
                                
                                k_char = str(k_char).lower()
                                
                                # Reset
                                if (self.config['macros']['reset']['enabled'] and 
                                    k_char == self.config['macros']['reset']['bind'].lower()):
                                    self.action_reset()

                                # Prefire
                                if (self.config['macros']['prefire']['enabled'] and 
                                    k_char == self.config['macros']['prefire']['bind'].lower()):
                                    self.action_prefire()
                                    
                                # Pickup (Hold)
                                if (self.config['macros']['pickup']['enabled'] and 
                                    k_char == self.config['macros']['pickup']['trigger'].lower()):
                                    if not self.active_loops.get('pickup'):
                                        self.active_loops['pickup'] = True
                                        threading.Thread(target=self.loop_pickup, daemon=True).start()

                                # Crouch (Hold)
                                if (self.config['macros']['crouch']['enabled'] and 
                                    k_char == self.config['macros']['crouch']['trigger'].lower()):
                                    if not self.active_loops.get('crouch'):
                                        self.active_loops['crouch'] = True
                                        threading.Thread(target=self.loop_crouch, daemon=True).start()

                            except Exception as e:
                                print(f"Key Error: {e}")

                        def on_release(self, key):
                            try:
                                k_char = None
                                if hasattr(key, 'char'): k_char = key.char
                                else: k_char = key.name
                                k_char = str(k_char).lower()

                                # Stop Pickup
                                if (self.config['macros']['pickup']['enabled'] and 
                                    k_char == self.config['macros']['pickup']['trigger'].lower()):
                                    self.active_loops['pickup'] = False

                                # Stop Crouch
                                if (self.config['macros']['crouch']['enabled'] and 
                                    k_char == self.config['macros']['crouch']['trigger'].lower()):
                                    self.active_loops['crouch'] = False

                            except: pass

                        def start(self):
                            # Watch for config changes
                            threading.Thread(target=self.watch_config, daemon=True).start()
                            
                            with keyboard.Listener(on_press=self.on_press, on_release=self.on_release) as listener:
                                listener.join()
                        
                        def watch_config(self):
                            last_mtime = 0
                            base_dir = os.path.dirname(os.path.abspath(__file__))
                            if getattr(sys, 'frozen', False):
                                base_dir = os.path.dirname(sys.executable)
                            config_path = os.path.join(base_dir, 'macro_config.json')
                            
                            while True:
                                try:
                                    if os.path.exists(config_path):
                                        mtime = os.stat(config_path).st_mtime
                                        if mtime > last_mtime:
                                            last_mtime = mtime
                                            self.load_config()
                                            print("Config Reloaded")
                                except: pass
                                time.sleep(1)


                    engine = MacroManager()
                    engine.start()

                except Exception as e:
                    print(f"Macro Error: {e}")
                    while True: time.sleep(1)
        except Exception as e:
            print(f"Script Error: {e}")
            while True: time.sleep(1)
    
    # --- Main Application Logic ---
    import webview
    
    api = Optimizer()
    
    # Handle both raw .py and frozen .exe paths
    if getattr(sys, 'frozen', False):
        base_dir = sys._MEIPASS
        # Check for config next to the executable
        exe_dir = os.path.dirname(sys.executable)
        config_path = os.path.join(exe_dir, 'config.json')
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(base_dir, 'config.json')

    # Load config if exists, otherwise use production URL default
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                import json
                config = json.load(f)
                api.api_url = config.get('api_url', api.api_url)
        except: pass
    else:
        # Default to production URL if no config found
        api.api_url = "https://titantweaksserver.onrender.com"
        
    file_path = os.path.join(base_dir, 'web', 'index.html')
    
    window = webview.create_window(
        'TitanTweaks', 
        file_path, 
        js_api=api,
        width=1000, 
        height=700,
        resizable=True,
        background_color='#0f172a',
        icon=os.path.join(base_dir, 'icon.ico')
    )
    # SECURITY: specific debug=False to prevent devtools access
    webview.start(debug=False)
