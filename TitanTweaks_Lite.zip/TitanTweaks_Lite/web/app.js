
// Wrapper for Python Tasks with Arguments
async function runTaskWithArg(functionName, arg) {
    if (!window.pywebview) return;
    showNotification("Applying Optimization...", "info");
    try {
        const result = await window.pywebview.api[functionName](arg);
        showNotification(result || "Done", "success");
    } catch (e) {
        showNotification("Error: " + e, "error");
    }
}

// AI Smart Scan
async function startAiScan() {
    const status = document.getElementById('ai-status');
    const icon = document.getElementById('ai-icon');
    const btn = document.querySelector('#ai_tab .btn-primary');

    // Animation
    status.textContent = "Analyzing System...";
    icon.style.animation = "pulse 1s infinite";
    btn.disabled = true;
    btn.style.opacity = '0.5';

    try {
        // Wait a bit for effect
        await new Promise(r => setTimeout(r, 1500));

        const results = await window.pywebview.api.ai_scan();

        icon.style.animation = "none";
        status.textContent = "Analysis Complete";
        document.getElementById('ai-desc').style.display = 'none';
        btn.style.display = 'none';

        const resultsDiv = document.getElementById('ai-results');
        const list = document.getElementById('ai-recommendations-list');
        list.innerHTML = '';

        results.forEach(rec => {
            const item = document.createElement('div');
            item.className = 'setting-item';
            item.innerHTML = `
                <div class="setting-info">
                    <h3 style="color: #fbbf24">${rec.label}</h3>
                    <p>${rec.fix}</p>
                </div>
                <i class="fa-solid fa-check" style="color: #10b981"></i>
            `;
            list.appendChild(item);
        });

        resultsDiv.style.display = 'block';

    } catch (e) {
        status.textContent = "Error Scanning";
        showNotification(e, 'error');
    }
}

function startApp() {
    fetchSpecs();
    initChart();
    loadSettings(); // NEW
    setInterval(updateStats, 1000);
}

// Settings Persistence
async function loadSettings() {
    if (!window.pywebview) return;
    try {
        const settings = await window.pywebview.api.get_settings();
        for (const [id, val] of Object.entries(settings)) {
            const el = document.getElementById(id);
            if (el && el.type === 'checkbox') {
                el.checked = val;
            }
        }

        // Load Macros
        const macroConfig = await window.pywebview.api.get_macro_config();
        if (macroConfig.macros) {
            for (const [key, val] of Object.entries(macroConfig.macros)) {
                // Enabled
                const chk = document.getElementById(`macro-${key}-enabled`);
                if (chk) chk.checked = val.enabled;

                // Bind
                const bind = document.getElementById(`macro-${key}-bind`);
                if (bind) bind.value = val.bind || '';

                // Delay
                const delay = document.getElementById(`macro-${key}-delay`);
                if (delay) delay.value = val.delay || 20;

                // Specifics
                if (key === 'pickup' || key === 'crouch') {
                    const trig = document.getElementById(`macro-${key}-trigger`);
                    if (trig) trig.value = val.trigger || '';
                }
                if (key === 'prefire') {
                    const wall = document.getElementById(`macro-${key}-wall_bind`);
                    if (wall) wall.value = val.wall_bind || '';
                }
            }
        }

    } catch (e) { console.error(e); }
}

function updateMacro(type) {
    if (!window.pywebview) return;

    const enabled = document.getElementById(`macro-${type}-enabled`).checked;

    // Dynamically collect all inputs for this macro
    let data = { enabled: enabled };

    // Find all inputs that start with macro-[type]-
    const container = document.getElementById(`macro-${type}-enabled`).closest('.card-glass');
    const inputs = container.querySelectorAll('input, select');

    inputs.forEach(input => {
        const key = input.id.replace(`macro-${type}-`, '');
        if (key === 'enabled') return; // already handled

        if (input.type === 'checkbox') {
            data[key] = input.checked;
        } else if (input.type === 'number' || input.type === 'range') {
            data[key] = parseInt(input.value);
        } else {
            data[key] = input.value;
        }
    });

    const payload = {
        macros: {
            [type]: data
        }
    };

    window.pywebview.api.update_macro_config(payload);
}


function applyPresetRes(w, h) {
    document.getElementById('res-w').value = w;
    document.getElementById('res-h').value = h;
    applyCustomRes();
}

async function applyCustomRes() {
    if (!window.pywebview) return;
    const w = document.getElementById('res-w').value;
    const h = document.getElementById('res-h').value;
    const modes = document.getElementsByName('res-mode');
    let mode = 'both';
    for (const m of modes) {
        if (m.checked) mode = m.value;
    }

    showNotification("Applying Resolution...", "info");
    const status = await window.pywebview.api.set_resolution(w, h, mode);
    showNotification(status, 'success');
}

async function fetchSpecs() {
    if (!window.pywebview) return;
    try {
        const specs = await window.pywebview.api.get_system_specs();
        document.getElementById('spec-cpu').textContent = specs.cpu;
        document.getElementById('spec-gpu').textContent = specs.gpu;
        document.getElementById('spec-ram').textContent = specs.ram;
        document.getElementById('spec-os').textContent = specs.os;
    } catch (e) { console.error(e); }
}

async function updateStats() {
    if (!window.pywebview) return;
    try {
        const stats = await window.pywebview.api.get_system_stats();

        // Update Chart Data
        cpuData.push(stats.cpu);
        cpuData.shift();
        ramData.push(stats.ram);
        ramData.shift();

        // Update Ping Text
        const pingEl = document.getElementById('ping-stat');
        if (pingEl) pingEl.textContent = stats.ping + " ms";

        // Redraw
        drawChart();

    } catch (e) {
        console.error("Stats update failed:", e);
    }
}

// Simple Canvas Chart (No Libs)
function initChart() {
    const canvas = document.getElementById('perfChart');
    if (canvas) {
        // Set resolution
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
    }
}

function drawChart() {
    const canvas = document.getElementById('perfChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    // Clear
    ctx.clearRect(0, 0, w, h);

    // Grid
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
        let y = (h / 4) * i;
        ctx.moveTo(0, y); ctx.lineTo(w, y);
    }
    ctx.stroke();

    // Draw Line helper
    const drawLine = (data, color) => {
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        const step = w / (historyLength - 1);

        data.forEach((val, i) => {
            const x = i * step;
            const y = h - ((val / 100) * h);
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        });
        ctx.stroke();

        // Glow effect
        ctx.shadowColor = color;
        ctx.shadowBlur = 10;
        ctx.stroke();
        ctx.shadowBlur = 0;
    };

    drawLine(cpuData, '#8b5cf6'); // Purple CPU
    drawLine(ramData, '#06b6d4'); // Cyan RAM
}

async function handleLogin() {
    const user = document.getElementById('login-user').value;
    const pass = document.getElementById('login-pass').value;
    const msg = document.getElementById('login-msg');

    if (!user || !pass) {
        msg.textContent = "Please enter creds."; return;
    }

    try {
        if (!window.pywebview) {
            msg.textContent = "App backend not connected."; return;
        }
        const response = await window.pywebview.api.check_login(user, pass);

        if (response.success) {
            localStorage.setItem('auth_token', response.token);
            localStorage.setItem('user_tier', response.tier);
            applyTierRestrictions(response.tier);

            document.getElementById('login-overlay').style.display = 'none';
            startApp();
        } else {
            msg.textContent = response.message || "Invalid Credentials";
        }
    } catch (e) {
        msg.textContent = "Error: " + e;
    }
}

async function handleLiteMode() {
    const msg = document.getElementById('login-msg');
    try {
        if (!window.pywebview) {
            msg.textContent = "App backend not connected."; return;
        }

        // Enter as basic/free user
        localStorage.setItem('auth_token', 'lite_guest_token');
        localStorage.setItem('user_tier', 'basic');
        applyTierRestrictions('basic');

        document.getElementById('login-overlay').style.display = 'none';
        startApp();
        showNotification("Running in Lite Mode", "info");
    } catch (e) {
        msg.textContent = "Error: " + e;
    }
}


// Notification System
function showNotification(message, type = 'success') {
    const area = document.getElementById('notification-area');
    const notif = document.createElement('div');
    notif.className = `notification ${type}`;
    notif.innerHTML = `
        <i class="fa-solid ${type === 'success' ? 'fa-check-circle' : 'fa-info-circle'}"></i>
        <span>${message}</span>
    `;

    // Style inline for simplicity or use CSS class
    notif.style.background = '#1e1e24';
    notif.style.border = `1px solid ${type === 'success' ? '#10b981' : '#3b82f6'}`;
    notif.style.padding = '1rem';
    notif.style.borderRadius = '10px';
    notif.style.color = 'white';
    notif.style.display = 'flex';
    notif.style.alignItems = 'center';
    notif.style.gap = '10px';
    notif.style.boxShadow = '0 10px 30px rgba(0,0,0,0.5)';
    notif.style.minWidth = '300px';
    notif.style.animation = 'slideIn 0.3s ease-out';

    area.appendChild(notif);

    setTimeout(() => {
        notif.style.opacity = '0';
        notif.style.transform = 'translateY(20px)';
        setTimeout(() => notif.remove(), 300);
    }, 4000);
}

// Wrapper for Python Tasks
async function runTask(functionName, successMessage = "Operation Completed") {
    if (!window.pywebview) {
        showNotification("Backend not connected (Dev Mode)", "info");
        return;
    }

    showNotification("Processing...", "info");

    try {
        // Dynamic call
        const result = await window.pywebview.api[functionName]();
        showNotification(successMessage || result || "Done", "success");
    } catch (e) {
        showNotification("Error: " + e, "error");
    }
}

function doLogout() {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_tier');
    location.reload();
}

function applyTierRestrictions(tier) {
    console.log("Applying Tier:", tier);
    const allPremium = document.querySelectorAll('[data-tier="premium"]');
    const allDeluxe = document.querySelectorAll('[data-tier="deluxe"]');

    // Reset
    const allItems = [...allPremium, ...allDeluxe];
    allItems.forEach(el => {
        el.classList.remove('locked');
        el.style.opacity = '1';
        el.style.pointerEvents = 'auto';
        // Remove lock icon if present
        const lock = el.querySelector('.lock-overlay');
        if (lock) lock.remove();
    });

    // Update Label
    const label = document.getElementById('user-tier-label');
    if (label) label.textContent = `v2.2.0 • Pricing: ${tier.toUpperCase()}`;

    // Admin gets everything
    if (tier === 'admin') return;

    // Basic User (No Premium, No Deluxe)
    if (tier === 'basic' || tier === 'free') {
        lockElements(allPremium);
        lockElements(allDeluxe);
    }

    // Premium User (Has Premium, No Deluxe)
    if (tier === 'premium') {
        lockElements(allDeluxe);
    }
}

function lockElements(elements) {
    elements.forEach(el => {
        el.classList.add('locked');
        el.style.opacity = '0.5';
        el.style.pointerEvents = 'none';
        el.style.position = 'relative';

        // Add lock icon if not exists
        if (!el.querySelector('.lock-overlay')) {
            const lock = document.createElement('div');
            lock.className = 'lock-overlay';
            lock.innerHTML = '<i class="fa-solid fa-lock"></i>';
            lock.style.position = 'absolute';
            lock.style.top = '50%';
            lock.style.left = '50%';
            lock.style.transform = 'translate(-50%, -50%)';
            lock.style.fontSize = '1.5rem';
            lock.style.color = '#fff';
            el.appendChild(lock);
        }
    });
}
let myChart = null;
const historyLength = 60;
const cpuData = new Array(historyLength).fill(0);
const ramData = new Array(historyLength).fill(0);

document.addEventListener('DOMContentLoaded', () => {
    // Auth Check
    const token = localStorage.getItem('auth_token');
    const savedTier = localStorage.getItem('user_tier') || 'basic';

    if (token) {
        document.getElementById('login-overlay').style.display = 'none';
        applyTierRestrictions(savedTier);
        startApp();
    }

    // Tabs
    const tabs = document.querySelectorAll('.nav-links li');
    const sections = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            sections.forEach(s => {
                s.style.display = 'none';
                s.classList.remove('active');
            });

            tab.classList.add('active');
            const targetId = tab.getAttribute('data-tab');
            const target = document.getElementById(targetId);
            if (target) {
                target.style.display = 'block';
                target.classList.add('active');
            }
        });
    });

    // Sub-Tabs Management (For General Tab)
    const subTabs = document.querySelectorAll('.sub-tab');
    if (subTabs.length > 0) {
        // Initial state: show only 'core' items
        filterSubTabItems('core');

        subTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                subTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                const category = tab.getAttribute('data-subtab');
                filterSubTabItems(category);
            });
        });
    }

    // Toggle Handlers
    document.querySelectorAll('.switch input').forEach(input => {
        input.addEventListener('change', (e) => {
            if (window.pywebview) {
                window.pywebview.api.update_setting(e.target.id, e.target.checked);
            }
        });
    });
});

function filterSubTabItems(category) {
    const allItems = document.querySelectorAll('.feature-card[data-group]');
    allItems.forEach(item => {
        if (item.getAttribute('data-group') === category || category === 'all') {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// Benchmark & Diagnostics
async function startBenchmark() {
    const ui = document.getElementById('bench-ui');
    const running = document.getElementById('bench-running');
    const results = document.getElementById('bench-results');
    const scoreText = document.getElementById('bench-score');
    const infoText = document.getElementById('bench-info');

    ui.style.display = 'none';
    results.style.display = 'none';
    running.style.display = 'block';

    try {
        const data = await window.pywebview.api.run_benchmark();

        // Simulate a bit of wait
        await new Promise(r => setTimeout(r, 2000));

        running.style.display = 'none';
        results.style.display = 'block';
        scoreText.textContent = data.score;
        infoText.textContent = `Completed in ${data.time} seconds. Your system is optimized for elite performance.`;

    } catch (e) {
        running.style.display = 'none';
        ui.style.display = 'block';
        showNotification("Benchmark Error: " + e, 'error');
    }
}

async function refreshDiags() {
    const list = document.getElementById('diag-list');
    list.innerHTML = '<div class="diag-item"><span>Scanning...</span></div>';

    try {
        const diagnostics = await window.pywebview.api.get_hardware_diagnostics();
        list.innerHTML = '';

        diagnostics.forEach(diag => {
            const item = document.createElement('div');
            item.className = 'diag-item';
            item.innerHTML = `
                <span style="color: white; font-weight: 500;">${diag.label}</span>
                <span class="status-${diag.status}">${diag.value}</span>
            `;
            list.appendChild(item);
        });
    } catch (e) {
        list.innerHTML = '<div class="diag-item"><span>Error scanning.</span></div>';
    }
}

