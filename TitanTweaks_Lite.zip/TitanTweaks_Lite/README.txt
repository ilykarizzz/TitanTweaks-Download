TitanTweaks (v2.1 - Premium)
=====================================

Features Included:
------------------
- Best Windows Settings
- Best System Registry
- Unseen Explorer Tweaks
- Best Network Settings
- Disable All Power Saving
- Custom Power Plan
- Best Power Settings
- Best Game Priority
- Best Latency Optimization (Zero Delay)
- Custom Graphics Driver
- Elite BIOS Power Plans (Hidden States)
- Bloom Reducer (Congestion Tweaks)
- Shotgun Pack (Low Latency)
- Best BCDEdit
- NVIDIA GPU Tweaks
- Radeon GPU Tweaks
- Custom Windows Cleaner
- DirectX Optimization
- Google Chrome Debloat
- Windows Debloat
- Discord Debloat
- Epicgames Debloat
- Best Latency Timing
- Complete Sound Optimization (Lowest Sound Latency)
- Better Alt Tab
- Complete Windows Debloat
- + Tons of extras not listed & multiple updates a month.

Outcome:
--------
FPS Boost, Reduction in Delay, Ping Decrease for Most People, Overall better performing machine.

Premium Features (v2.1):
------------------------
- Premium Login System: The app is now locked behind a subscription.
- Sales Website: A professional landing page to sell the app.

How to Test Locally:
--------------------
1. Start the Authentication Server:
   Open a terminal and run: `venv\Scripts\python website\server.py`
   (Or run "Start_Server.bat" if created).
   
2. Start the App:
   Double-click "Launch_Optimizer.bat".

3. Get Credentials:
   Open your browser to `http://localhost:5000`.
   Click "Get Access" -> "Pay".
   Use the generated Username/Password to login to the app.

Deployment Guide (For Friends):
-------------------------------
1. HOST THE WEBSITE: Upload the `website` folder to a hosting provider that supports Python (like Render.com, Railway.app, or Heroku).
2. UPDATE THE APP: Edit `optimizer.py`. Search for "http://localhost:5000" and replace it with your real website URL (e.g., "https://my-fn-optimizer.onrender.com").
3. DISTRIBUTE: Zip the folder and send it to friends. They will buy from your site and login to the app.
