import sys
import time
import json
import os
import threading
from pynput import keyboard, mouse
from pynput.keyboard import Key, Controller as KeyboardController
from pynput.mouse import Button, Controller as MouseController

# Constants
CONFIG_FILE = 'macro_config.json'

class FortniteMacro:
    def __init__(self):
        self.keyboard = KeyboardController()
        self.mouse = MouseController()
        self.running = True
        self.config = self.load_config()
        self.trigger_key = self.parse_key(self.config.get('trigger_key', 'v'))
        self.edit_key = self.parse_key(self.config.get('edit_key', 'f'))
        
        # State
        self.listener_k = None
        self.listener_m = None

    def load_config(self):
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, 'r') as f:
                    return json.load(f)
        except: pass
        return {
            "trigger_key": "v", 
            "edit_key": "f",
            "delay": 0.05
        }

    def parse_key(self, key_str):
        if len(key_str) == 1:
            return key_str.lower()
        # Handle special keys
        return getattr(Key, key_str, None)

    def perform_edit_reset(self):
        # Sequence: Edit -> Reset (Right Click) -> Confirm (Edit Key)
        # This assumes "Confirm Edit on Release" is OFF or effectively managed
        
        delay = self.config.get('delay', 0.05)
        
        # 1. Open Edit
        self.keyboard.press(self.edit_key)
        self.keyboard.release(self.edit_key)
        time.sleep(delay)
        
        # 2. Reset (Right Click)
        self.mouse.click(Button.right)
        time.sleep(delay)
        
        # 3. Confirm (Edit Key again)
        self.keyboard.press(self.edit_key)
        self.keyboard.release(self.edit_key)
        
        print("Macro Executed")

    def on_press(self, key):
        try:
            k = None
            if hasattr(key, 'char'):
                k = key.char
            else:
                k = key

            # Check Trigger
            if k == self.trigger_key:
                self.perform_edit_reset()
                
        except Exception as e:
            print(f"Error: {e}")

    def start(self):
        print(f"Macro Started. Trigger: {self.trigger_key}, Edit: {self.edit_key}")
        with keyboard.Listener(on_press=self.on_press) as self.listener_k:
            self.listener_k.join()

if __name__ == "__main__":
    macro = FortniteMacro()
    macro.start()
