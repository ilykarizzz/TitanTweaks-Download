import webview
import os
import sys

# --- DEBUG & FIX PATHS ---
try:
    # Ensure current directory is in sys.path
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.append(cwd)
        
    print("DEBUG PRE-IMPORT:")
    print(f"CWD: {cwd}")
    print(f"File exists (optimizer.py): {os.path.exists(os.path.join(cwd, 'optimizer.py'))}")
    
    from optimizer import Optimizer
except ImportError as e:
    print(f"CRITICAL ERROR: Failed to import optimizer: {e}")
    # Last ditch attempt: finding where this script actually is
    script_dir = os.path.dirname(os.path.abspath(__file__))
    if script_dir not in sys.path:
        sys.path.append(script_dir)
        try:
             print(f"Retrying import from script dir: {script_dir}")
             from optimizer import Optimizer
        except ImportError as e2:
             print(f"FATAL: Still could not import optimizer: {e2}")
             import time
             time.sleep(10)
             sys.exit(1)

# Fix for High DPI displays
try:
    from ctypes import windll
    windll.shcore.SetProcessDpiAwareness(1)
except:
    pass

class API:
    def __init__(self):
        self.optimizer = Optimizer()

    def get_system_stats(self):
        return self.optimizer.get_system_stats()

    def get_system_specs(self):
        return self.optimizer.get_system_specs()

    def optimize_all(self):
        return self.optimizer.optimize_all()

    def debloat_windows(self):
        return self.optimizer.debloat_windows()

    def optimize_dns(self):
        return self.optimizer.optimize_dns()

    def flush_dns(self):
        return self.optimizer.flush_dns()

    def clean_temp(self):
        return self.optimizer.clean_temp()
    
    def clean_shader_cache(self):
        return self.optimizer.clean_shader_cache()

    def clean_discord(self):
        return self.optimizer.clean_discord()

    def clean_spotify(self):
        return self.optimizer.clean_spotify()

    def check_login(self, username, password):
        return self.optimizer.check_login(username, password)

    def open_link(self, url):
        import webbrowser
        webbrowser.open(url)


    def update_setting(self, setting_id, value):
        return self.optimizer.update_setting(setting_id, value)

    def optimize_explorer(self):
        return self.optimizer.optimize_explorer()

    def optimize_nvidia(self):
        return self.optimizer.optimize_nvidia()

    def optimize_radeon(self):
        return self.optimizer.optimize_radeon()

    def optimize_directx(self):
        return self.optimizer.optimize_directx()
        
    def debloat_epic(self):
        return self.optimizer.debloat_epic()

    def debloat_chrome(self):
        return self.optimizer.debloat_chrome()

    def get_settings(self):
        return self.optimizer.get_settings()

    def ai_scan(self):
        return self.optimizer.ai_scan()

    def optimize_game(self, game_name):
        return self.optimizer.optimize_game(game_name)

    def create_restore_point(self):
        return self.optimizer.create_restore_point()

    def deep_debloat(self):
        return self.optimizer.deep_debloat()

    def optimize_nvidia_advanced(self):
        return self.optimizer.optimize_nvidia_advanced()

    def optimize_hpet(self, disable=True):
        return self.optimizer.optimize_hpet(disable)

    def optimize_msi_mode(self):
        return self.optimizer.optimize_msi_mode()

    def optimize_usb_latency(self):
        return self.optimizer.optimize_usb_latency()

    def optimize_controller_latency(self):
        return self.optimizer.optimize_controller_latency()

    def optimize_ram_timing(self):

        return self.optimizer.optimize_ram_timing()

    def run_benchmark(self):
        return self.optimizer.run_benchmark()

    def get_hardware_diagnostics(self):
        return self.optimizer.get_hardware_diagnostics()

    def get_macro_config(self):

        return self.optimizer.get_macro_config()

    def update_macro_config(self, config):
        return self.optimizer.update_macro_config(config)

    def set_resolution(self, width, height, mode):
        return self.optimizer.set_resolution(width, height, mode)

    def apply_fortnite_config(self, level="performance"):
        return self.optimizer.apply_fortnite_config(level)


def main():
    api = API()
    
    # Determine the absolute path to the HTML file
    if hasattr(sys, '_MEIPASS'):
        # PyInstaller
        current_dir = sys._MEIPASS
    elif getattr(sys, 'frozen', False):
        # cx_Freeze
        current_dir = os.path.dirname(sys.executable)
    else:
        current_dir = os.path.dirname(os.path.abspath(__file__))
    
    import pathlib
    html_path = os.path.join(current_dir, 'web', 'index.html')
    html_uri = pathlib.Path(html_path).as_uri()
    icon_path = os.path.join(current_dir, 'icon.ico')

    window = webview.create_window(
        'TitanTweaks',
        url=html_uri,
        js_api=api,
        width=1000,
        height=720,
        resizable=True,
        background_color='#0a0b10',
        frameless=False
    )
    
    webview.start(debug=False)

if __name__ == '__main__':
    main()
